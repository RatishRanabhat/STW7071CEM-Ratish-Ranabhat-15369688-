import numpy as np
import os
import pandas as pd
from flask import Flask, request, render_template, flash
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import re
import nltk
import threading
import schedule
import time
import feedparser
import matplotlib.pyplot as plt

# Initialize Flask app
app = Flask(__name__)
app.secret_key = "supersecretkey"

# Global variables for vectorizer and KMeans model
vectorizer = None
kmeans = None
X_train = None

# Constants for limits
MAX_FEEDS_PER_CATEGORY = 300
MAX_ARTICLES_PER_FEED = 50

# Predefined keywords for different categories
predefined_keywords = {
    0: [  # Economics
        "economy", "finance", "market", "investment", "growth", "inflation", "stock", "economic", "currency",
        "recession", "bond", "trade", "supply", "demand", "interest rates", "globalization", "GDP",
        "fiscal policy", "monetary policy", "capital", "asset", "liability", "financial", "bank", "credit",
        "deficit", "surplus", "econometrics", "economic indicators", "economic development", "business cycle",
        "economic crisis", "business investment", "consumer spending", "economic growth", "financial markets",
        "economic reform", "economic theory", "market trends", "economic impact", "inflation rate", "economic policy",
        "investment banking", "portfolio", "asset management", "real estate", "mergers and acquisitions", "financial planning",
        "stock market", "capital markets", "economic stability", "taxation", "financial analysis", "economic theory",
        "private equity", "venture capital", "commodity trading", "market volatility", "wealth management"
    ],
    1: [  # Entertainment & Sports
        "entertainment", "celebrity", "film", "music", "show", "theater", "actor", "actress", "performance",
        "Hollywood", "drama", "comedy", "musical", "concert", "album", "review", "director", "producer",
        "screenplay", "box office", "red carpet", "award", "celebrity gossip", "pop culture", "celebrity news",
        "fashion", "music industry", "theatrical", "performance art", "dance", "opera", "musician", "band",
        "soundtrack", "television", "reality show", "talk show", "film industry", "arts", "entertainment news",
        "sports", "athlete", "team", "game", "tournament", "match", "championship", "score", "goal", "coach",
        "training", "competition", "sports news", "football", "basketball", "baseball", "soccer", "hockey",
        "tennis", "rugby", "volleyball", "gymnastics", "swimming", "athletics", "track and field", "olympics",
        "world cup", "sports event", "fitness", "exercise", "sportsmanship", "sports league", "sports team",
        "stadium", "arena", "sports fan", "athletic performance", "sports broadcaster", "sports betting", "sports analysis",
        "athletic wear", "sports equipment", "sports medicine", "doping", "eSports", "sporting event"
    ],
    2: [  # Politics
        "politics", "election", "government", "policy", "campaign", "legislation", "debate", "politician",
        "congress", "senate", "president", "prime minister", "parliament", "party", "constitution", "law",
        "diplomacy", "foreign policy", "public opinion", "political party", "electoral", "referendum",
        "political theory", "human rights", "social justice", "political system", "government reform",
        "political activism", "campaign finance", "voting", "political spectrum", "policy analysis", "political corruption",
        "international relations", "political debate", "policy proposal", "government budget", "political issues",
        "political history", "legislative process", "political movements", "political philosophy", "public policy",
        "government institutions", "political economy", "civil rights", "geopolitics", "law and order", "political strategy",
        "democracy", "authoritarianism", "political reform", "electoral system", "political scandal", "political rhetoric",
        "foreign relations", "government transparency", "political debate", "policy implementation", "social policy"
    ]
}

# Download necessary NLTK data
nltk.download("punkt")
nltk.download("stopwords")
nltk.download("wordnet")

def preprocess_text(text):
    """Clean and preprocess text."""
    text = re.sub(r"http\S+|www\S+|https\S+", "", text, flags=re.MULTILINE)  # Remove URLs
    text = re.sub(r"\s*\|\s*Fox\s+News\b", "", text, flags=re.IGNORECASE)  # Remove Fox News label
    text = re.sub(r"\s*\|\s*Fox\s+Business\b", "", text, flags=re.IGNORECASE)  # Remove Fox Business label
    text = re.sub(r"\s*-\s*BBC\s+News\b", "", text, flags=re.IGNORECASE)  # Remove BBC News label
    text = re.sub(r"\s*-\s*The\s+Economic\s+Times\b", "", text, flags=re.IGNORECASE)  # Remove The Economic Times label
    text = text.strip()  # Remove leading and trailing whitespace
    return text

def find_top_keywords(X, labels, n_top_keywords=80):
    """Find the top keywords for each cluster."""
    feature_names = vectorizer.get_feature_names_out()
    cluster_keywords = {}

    for cluster_num in np.unique(labels):
        cluster_indices = np.where(labels == cluster_num)[0]
        cluster_texts = [X[i] for i in cluster_indices]
        cluster_vector = np.mean(cluster_texts, axis=0)
        sorted_indices = np.argsort(cluster_vector)[::-1]
        top_indices = sorted_indices[:n_top_keywords]
        top_keywords = [feature_names[i] for i in top_indices]
        
        # Combine predefined keywords with top keywords
        predefined_keywords_list = predefined_keywords.get(cluster_num, [])
        combined_keywords = list(set(predefined_keywords_list) | set(top_keywords))
        
        cluster_keywords[cluster_num] = combined_keywords

    return cluster_keywords

def assign_cluster_to_document(document, cluster_keywords):
    """Assign a cluster to a given document based on keywords."""
    document_keywords = set(document.lower().split())
    best_cluster = -1
    max_keywords_matched = 0

    for cluster_num, cluster_keywords in predefined_keywords.items():
        cluster_keywords_set = set(cluster_keywords)
        matched_keywords = len(document_keywords.intersection(cluster_keywords_set))
        if matched_keywords > max_keywords_matched:
            max_keywords_matched = matched_keywords
            best_cluster = cluster_num

    # If no predefined cluster is found, use KMeans clustering
    if best_cluster == -1:
        document_vector = vectorizer.transform([document]).toarray()
        kmeans_cluster = kmeans.predict(document_vector)[0]
        cluster_keywords = predefined_keywords.get(kmeans_cluster, [])
        matched_keywords = len(document_keywords.intersection(set(cluster_keywords)))
        
        if matched_keywords > max_keywords_matched:
            best_cluster = kmeans_cluster
        else:
            best_cluster = kmeans_cluster

    return best_cluster, get_cluster_name(best_cluster)

def get_cluster_name(cluster_num):
    """Get the name of the cluster based on the cluster number."""
    cluster_names = {0: "Economics", 1: "Entertainment", 2: "Politics"}
    return cluster_names.get(cluster_num, "Unknown")

def plot_clusters(X, labels, centers):
    """Plot clusters and their centroids."""
    if not plt.isinteractive():
        plt.switch_backend('agg')

    n_components = min(X.shape[1], 2)

    if X.shape[0] <= 1 or X.shape[1] <= 1:
        plt.figure(figsize=(12, 8))
        plt.scatter(X[:, 0], np.zeros_like(X[:, 0]), c=labels, cmap="viridis", alpha=0.6, edgecolors='w', s=50)
        plt.scatter(centers[:, 0], np.zeros_like(centers[:, 0]), c='red', s=200, alpha=0.75, marker='x', label='Centroids')
        plt.colorbar(label='Cluster')
        plt.title("K-means Clustering of Documents (Original Space)")
        plt.xlabel("Feature")
        plt.savefig('kmeans_plot.png')
        plt.close()
        return

    pca = PCA(n_components=n_components)
    X_pca = pca.fit_transform(X)

    if n_components == 1:
        centers_pca = np.zeros((centers.shape[0], 1))
        centers_pca[:, 0] = pca.transform(centers).flatten()
        plt.figure(figsize=(12, 8))
        plt.scatter(X_pca, np.zeros_like(X_pca), c=labels, cmap="viridis", alpha=0.6, edgecolors='w', s=50)
        plt.scatter(centers_pca, np.zeros_like(centers_pca), c='red', s=200, alpha=0.75, marker='x', label='Centroids')
        plt.colorbar(label='Cluster')
        plt.title("K-means Clustering of Documents (PCA Reduced)")
        plt.xlabel("Principal Component")
    else:
        centers_pca = pca.transform(centers)
        plt.figure(figsize=(12, 8))
        scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels, cmap="viridis", alpha=0.6, edgecolors='w', s=50)
        plt.scatter(centers_pca[:, 0], centers_pca[:, 1], c='red', s=200, alpha=0.75, marker='x', label='Centroids')
        plt.colorbar(scatter, label='Cluster')
        plt.title("K-means Clustering of Documents (PCA Reduced)")
        plt.xlabel("Principal Component 1")
        plt.ylabel("Principal Component 2")

    plt.legend()
    plt.savefig('kmeans_plot.png')
    plt.close()

def cluster_documents(documents, max_clusters=3):
    """Cluster documents using KMeans and update document clusters."""
    global vectorizer, kmeans, X_train
    if not documents:
        return []

    texts = [doc["Document"] for doc in documents]
    preprocessed_texts = [preprocess_text(text) for text in texts]

    if vectorizer is None:
        vectorizer = TfidfVectorizer(stop_words="english", min_df=1)

    if X_train is None:
        X_train = vectorizer.fit_transform(preprocessed_texts).toarray()
    else:
        X_new = vectorizer.transform(preprocessed_texts).toarray()
        X_train = np.vstack((X_train, X_new))

    num_samples = X_train.shape[0]
    if max_clusters > num_samples:
        max_clusters = num_samples

    if kmeans is None:
        kmeans = KMeans(n_clusters=max_clusters, random_state=42)
    else:
        kmeans.n_clusters = max_clusters

    kmeans.fit(X_train)
    labels = kmeans.predict(X_train)

    cluster_keywords = find_top_keywords(X_train, kmeans.labels_)

    for cluster_num, keywords in cluster_keywords.items():
        print(f"Cluster {cluster_num} top keywords: {keywords}")

    for i, doc in enumerate(documents):
        doc["Cluster"] = labels[i]
        doc["Cluster Name"] = get_cluster_name(labels[i])

    plot_clusters(X_train, kmeans.labels_, kmeans.cluster_centers_)

    return documents

def assign_cluster_and_save(clustered_docs):
    """Save clustered documents to a CSV file."""
    filename = "clustered_documents.csv"
    if os.path.exists(filename):
        df_existing = pd.read_csv(filename)
    else:
        df_existing = pd.DataFrame(columns=["Document", "Cluster", "Cluster Name"])

    df_new = pd.DataFrame(clustered_docs)
    df_combined = pd.concat([df_existing, df_new], ignore_index=True)
    df_combined.drop_duplicates(subset=["Document"], keep="last", inplace=True)
    df_combined.to_csv(filename, index=False)
    return df_combined

def merge_and_cluster_documents(new_documents):
    """Merge new documents with existing ones, cluster them, and return the updated DataFrame."""
    filename = "clustered_documents.csv"
    if os.path.exists(filename):
        df_existing = pd.read_csv(filename)
    else:
        df_existing = pd.DataFrame(columns=["Document", "Cluster", "Cluster Name"])

    all_documents = pd.concat([df_existing, pd.DataFrame(new_documents)], ignore_index=True)
    
    clustered_docs = cluster_documents(all_documents.to_dict(orient="records"), max_clusters=3)
    
    return pd.DataFrame(clustered_docs)


def fetch_articles_from_feed(urls, category):
    """Fetch articles from RSS feeds and return a list of articles."""
    all_articles = []
    for url in urls:
        feed = feedparser.parse(url)
        count = 0
        for entry in feed.entries:
            if count >= MAX_ARTICLES_PER_FEED:
                break
            title = entry.title
            summary = entry.summary if hasattr(entry, 'summary') else ""
            article = {
                "Document": f"{title}: {summary}",
                "Cluster": -1,
                "Cluster Name": category
            }
            all_articles.append(article)
            count += 1
        if len(all_articles) >= MAX_FEEDS_PER_CATEGORY:
            break
    return all_articles

@app.route("/", methods=["GET", "POST"])
def index():
    """Handle the index page with document submission."""
    show_popup = False
    popup_message = ""

    if request.method == "POST":
        document = request.form.get("document")

        if not document or document.strip() == "":
            popup_message = "Document cannot be empty. Please enter some text."
            show_popup = True
        else:
            filename = "clustered_documents.csv"
            df_existing = pd.read_csv(filename) if os.path.exists(filename) else pd.DataFrame(columns=["Document", "Cluster", "Cluster Name"])

            if document in df_existing["Document"].values:
                assigned_doc = df_existing[df_existing["Document"] == document].iloc[0]
                cluster_num = assigned_doc["Cluster"]
                cluster_name = assigned_doc["Cluster Name"]

                popup_message = f"Document already exists and is assigned to cluster '{cluster_name}'."
            else:
                new_document = {
                    "Document": document,
                    "Cluster": -1,
                    "Cluster Name": ""
                }
                
                updated_df = merge_and_cluster_documents([new_document])
                
                all_keywords = find_top_keywords(X_train, kmeans.labels_)
                cluster_num, cluster_name = assign_cluster_to_document(document, all_keywords)
                
                if cluster_num != -1:
                    doc = {
                        "Document": document,
                        "Cluster": cluster_num,
                        "Cluster Name": cluster_name
                    }
                    updated_df = pd.concat([updated_df, pd.DataFrame([doc])], ignore_index=True)
                    updated_df.drop_duplicates(subset=["Document"], keep="last", inplace=True)
                    updated_df.to_csv(filename, index=False)
                    popup_message = f"Document assigned to cluster '{cluster_name}' successfully."
                else:
                    default_cluster_num = 0
                    default_cluster_name = get_cluster_name(default_cluster_num)
                    doc = {
                        "Document": document,
                        "Cluster": default_cluster_num,
                        "Cluster Name": default_cluster_name
                    }
                    updated_df = pd.concat([updated_df, pd.DataFrame([doc])], ignore_index=True)
                    updated_df.drop_duplicates(subset=["Document"], keep="last", inplace=True)
                    updated_df.to_csv(filename, index=False)
                    popup_message = f"Document did not match any predefined clusters. Assigned to default cluster '{default_cluster_name}'."
                
            show_popup = True

    return render_template("index.html", show_popup=show_popup, popup_message=popup_message)

@app.route("/search", methods=["POST"])
def search():
    """Search for documents containing the query."""
    query = request.form.get("query")
    if not query:
        flash("Please enter a search query.", "warning")
        return render_template("index.html", show_popup=False, popup_message="")

    filename = "clustered_documents.csv"
    if not os.path.exists(filename):
        flash("No clustered documents available. Please fetch and cluster data first.", "warning")
        return render_template("index.html", show_popup=False, popup_message="")

    df = pd.read_csv(filename)
    matched_docs = df[df["Document"].str.contains(query, case=False, na=False)]

    return render_template("results.html", results=matched_docs.to_dict(orient="records"))

def job():
    """Scheduled job to fetch articles, cluster them, and save them."""
    all_articles = []
    feeds = {
        "Economics": [
            "http://feeds.bbci.co.uk/news/business/economy/rss.xml",
            "https://feeds.foxnews.com/foxnews/business",
            "https://economictimes.indiatimes.com/rssfeedsdefault.cms",
        ],
        "Entertainment": [
            "http://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml",
            "https://feeds.foxnews.com/foxnews/entertainment",
            "https://economictimes.indiatimes.com/rssfeedsdefault.cms",
        ],
        "Politics": [
            "http://feeds.bbci.co.uk/news/politics/rss.xml",
            "https://feeds.foxnews.com/foxnews/politics",
            "https://economictimes.indiatimes.com/rssfeedsdefault.cms",
        ]
    }
    
    for category, urls in feeds.items():
        articles = fetch_articles_from_feed(urls, category)
        if articles:
            clustered_docs = cluster_documents(articles, max_clusters=3)
            if clustered_docs:
                all_articles.extend(clustered_docs)

    if all_articles:
        assign_cluster_and_save(all_articles)
    else:
        print("No documents to cluster.")

def run_scheduler():
    """Run the scheduler to periodically execute the job."""
    schedule.every().week.do(job)
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    print("Initializing application...")
    job()  # Initial run of the job to fetch and cluster documents

    # Start the scheduler thread to run the job weekly
    scheduler_thread = threading.Thread(target=run_scheduler)
    scheduler_thread.start()

    # Run the Flask app
    app.run(debug=True)
