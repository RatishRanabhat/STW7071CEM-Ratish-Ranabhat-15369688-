from flask import Flask, render_template, request, redirect, url_for
from elasticsearch import Elasticsearch
import requests
from bs4 import BeautifulSoup
import re
import schedule
from collections import defaultdict
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# Download necessary NLTK resources
nltk.download("punkt", quiet=True)
nltk.download("stopwords", quiet=True)
nltk.download("wordnet", quiet=True)

# Initialize Flask app and Elasticsearch client
app = Flask(__name__)
es = Elasticsearch([{"host": "localhost", "port": 9200, "scheme": "http"}])

# Define constants
PURE_PORTAL_URL = "https://pureportal.coventry.ac.uk/en/organisations/eec-school-of-computing-mathematics-and-data-sciences-cmds/publications/"
STOP_WORDS = set(stopwords.words("english"))
WN_LEMMATIZER = WordNetLemmatizer()
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}

def preprocess(text):

    """
    Preprocess the input text by tokenizing, removing stop words,
    and lemmatizing.
    """
    tokens = nltk.word_tokenize(text)
    tokens = [
        word.lower()
        for word in tokens
        if word.isalpha() and word.lower() not in STOP_WORDS
    ]
    tokens = [WN_LEMMATIZER.lemmatize(word) for word in tokens]
    return tokens

def crawl_and_parse(url):
    """
    Crawl the specified URL, parse the HTML content, and extract
    publication details. Handles pagination and additional pages.
    """
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        soup = BeautifulSoup(response.content, "html.parser")
        results = []
        # Proceed with the further data extraction


        # Extract publication containers from the page
        publication_containers = soup.find_all("div", class_="result-container")

        for container in publication_containers:
            title_tag = container.find("h3", class_="title")
            title = title_tag.text.strip() if title_tag else "No title"
            link_tag = title_tag.find("a")
            link = (
                url + link_tag["href"]
                if link_tag and link_tag["href"].startswith("/")
                else link_tag["href"]
            )
            authors_with_links = [
                {"url": author_tag["href"], "name": author_tag.text.strip()}
                for author_tag in container.find_all("a", class_="link person")
            ]
            authors_without_links = [
                author_tag.text.strip()
                for author_tag in container.find_all("span", class_=False)
                if author_tag.text.strip() not in [a["name"] for a in authors_with_links]
            ]
            if any(title.lower() in author.lower() for author in authors_without_links):
                authors_without_links = [author.replace(title, "").strip() for author in authors_without_links]
            authors_without_links = list(filter(None, authors_without_links))
            title = re.sub(r'Authors: .*?,', '', title).strip()
            date_tag = container.find("span", class_="date")
            publication_date = date_tag.text.strip() if date_tag else "No date"
            abstract_tag = container.find("div", class_="rendering_abstractportal")
            abstract = abstract_tag.text.strip() if abstract_tag else ""
            results.append(
                {
                    "title": title,
                    "link": link,
                    "authors_with_links": authors_with_links,
                    "authors_without_links": authors_without_links,
                    "publication_date": publication_date,
                    "abstract": abstract,
                    "content": f"{title} {' '.join([a['name'] for a in authors_with_links])} {' '.join(authors_without_links)} {publication_date} {abstract}",
                }
            )
        
        # Handle pagination
        next_page_link = soup.find("a", class_="next")
        if next_page_link:
            next_page_url = url + next_page_link["href"]
            results.extend(crawl_and_parse(next_page_url))
        
        # Handle additional view-all links
        view_all_links = soup.find_all("div", class_="view all")
        for view_link in view_all_links:
            view_url = view_link.find("a")["href"]
            view_response = requests.get(view_url, headers=headers)
            if view_response.status_code == 200:
                view_soup = BeautifulSoup(view_response.content, "html.parser")
                view_results = view_soup.find_all("div", class_="result-container")
                for view_container in view_results:
                     # Proceed with the further data extraction from view_container similarly as above

                    view_title_tag = view_container.find("h3", class_="title")
                    view_title = (
                        view_title_tag.text.strip() if view_title_tag else "No title"
                    )
                    view_link_tag = view_title_tag.find("a")
                    view_link = (
                        url + view_link_tag["href"]
                        if view_link_tag and view_link_tag["href"].startswith("/")
                        else view_link_tag["href"]
                    )
                    view_authors_with_links = [
                        {"url": author_tag["href"], "name": author_tag.text.strip()}
                        for author_tag in view_container.find_all("a", class_="link person")
                    ]
                    view_authors_without_links = [
                        author_tag.text.strip()
                        for author_tag in view_container.find_all("span", class_=False)
                        if author_tag.text.strip() not in [a["name"] for a in view_authors_with_links]
                    ]
                    if any(view_title.lower() in author.lower() for author in view_authors_without_links):
                        view_authors_without_links = [author.replace(view_title, "").strip() for author in view_authors_without_links]
                    view_authors_without_links = list(filter(None, view_authors_without_links))
                    view_title = re.sub(r'Authors: .*?,', '', view_title).strip()
                    view_date_tag = view_container.find("span", class_="date")
                    view_publication_date = (
                        view_date_tag.text.strip() if view_date_tag else "No date"
                    )
                    view_abstract_tag = view_container.find(
                        "div", class_="rendering_abstractportal"
                    )
                    view_abstract = (
                        view_abstract_tag.text.strip()
                        if view_abstract_tag
                        else ""
                    )
                    results.append(
                        {
                            "title": view_title,
                            "link": view_link,
                            "authors_with_links": view_authors_with_links,
                            "authors_without_links": view_authors_without_links,
                            "publication_date": view_publication_date,
                            "abstract": view_abstract,
                            "content": f"{view_title} {' '.join([a['name'] for a in view_authors_with_links])} {' '.join(view_authors_without_links)} {view_publication_date} {view_abstract}",
                        }
                    )
        return results
    else:
        print(f"Failed to retrieve page: {url}")
        return []

def create_inverted_index(documents):
    """
    Create an inverted index from the list of documents.
    """
    inverted_index = defaultdict(list)
    for doc_id, doc in enumerate(documents):
        content = doc["content"]
        words = preprocess(content)
        for word in set(words):
            inverted_index[word].append(doc_id)
    return inverted_index

def calculate_tf_idf(documents):
    """
    Calculate TF-IDF matrix for the list of documents.
    """
    corpus = [doc["content"] for doc in documents]
    vectorizer = TfidfVectorizer(tokenizer=preprocess, stop_words="english")
    tfidf_matrix = vectorizer.fit_transform(corpus)
    return tfidf_matrix, vectorizer

def update_index(es, documents):
    """
    Update Elasticsearch index with the new documents.
    """
    try:
        if not es.indices.exists(index="cmds_publications"):
            es.indices.create(index="cmds_publications")
            print("Created index: cmds_publications")
        else:
            print("Index already exists: cmds_publications")
    except Exception as e:
        print(f"Error creating index: {e}")
    for doc_id, doc in enumerate(documents):
        try:
            es.index(index="cmds_publications", body=doc, id=doc_id)
            print(f"Indexed document {doc_id}: {doc['title']}")
        except Exception as e:
            print(f"Error indexing document {doc_id}: {e}")

def search(query, es, vectorizer, tfidf_matrix, documents):
    """
    Perform a search on the documents using the query.
    """
    query = re.sub(r"[^\w\s]", "", query)
    query_tokens = preprocess(query)
    query_vector = vectorizer.transform([" ".join(query_tokens)])
    cosine_similarities = cosine_similarity(query_vector, tfidf_matrix).flatten()
    results_with_scores = list(zip(documents, cosine_similarities))
    results_with_scores.sort(key=lambda x: x[1], reverse=True)
    return results_with_scores

def scheduled_crawl():
    """
    Perform scheduled crawling and indexing.
    """
    print("Scheduled crawling started.")
    documents = crawl_and_parse(PURE_PORTAL_URL)
    create_inverted_index(documents)
    calculate_tf_idf(documents)
    update_index(es, documents)
    print("Scheduled crawling completed.")

# Schedule the crawling task to run every 7 days
schedule.every(7).days.do(scheduled_crawl)

@app.route("/")
def index():
    """
    Render the home page.
    """
    return render_template("index.html", message="")

@app.route("/search", methods=["GET", "POST"])
def search_route():
    """
    Handle search queries and display results.
    """
    if request.method == "POST":
        query = request.form["query"]
        if query.strip() == "":
            return render_template("index.html", message="Please enter a query.")
        
        # Perform search
        documents = crawl_and_parse(PURE_PORTAL_URL)
        create_inverted_index(documents)
        tfidf_matrix, vectorizer = calculate_tf_idf(documents)
        search_results = search(query, es, vectorizer, tfidf_matrix, documents)
        
        if not search_results:
            return render_template(
                "results.html",
                relevant_results=[],
                less_relevant_results=[],
                query=query,
                message=f"No results found for '{query}'.",
            )
        
        # Pagination setup
        page = int(request.args.get("page", 1))
        results_per_page = 20
        start_index = (page - 1) * results_per_page
        end_index = start_index + results_per_page
        paginated_results = search_results[start_index:end_index]
        
        # Split results into relevant and less relevant
        relevant_results = [
            (doc, score) for doc, score in paginated_results if score > 0
        ]
        less_relevant_results = [
            (doc, score) for doc, score in paginated_results if score == 0
        ]
        
        return render_template(
            "results.html",
            relevant_results=relevant_results,
            less_relevant_results=less_relevant_results,
            query=query,
            current_page=page,
        )
    
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
